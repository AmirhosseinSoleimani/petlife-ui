import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';

import { AuthService } from '../../../core/auth/auth.service';
import { AppLanguage, I18nService, SUPPORTED_LANGUAGES } from '../../../core/i18n/i18n.service';
import { AuthUser } from '../../../core/models/auth.models';
import { UserPreferencesService } from '../../../core/preferences/user-preferences.service';

interface NavItem {
  labelKey: string;
  path: string;
  icon: string;
  enabled: boolean;
}

@Component({
  selector: 'app-shell',
  templateUrl: './app-shell.component.html',
  styleUrls: ['./app-shell.component.scss']
})
export class AppShellComponent implements OnInit, OnDestroy {
  isDrawerOpen = false;
  isPreferencesOpen = false;

  private readonly customerNavItems: NavItem[] = [
    { labelKey: 'nav.dashboard', path: '/dashboard', icon: 'dashboard', enabled: true },
    { labelKey: 'Profile', path: '/profile', icon: 'providers', enabled: true },
    { labelKey: 'nav.pets', path: '/pets', icon: 'pets', enabled: true },
    { labelKey: 'nav.reminders', path: '/reminders', icon: 'reminders', enabled: true },
    { labelKey: 'nav.providers', path: '/providers', icon: 'providers', enabled: true },
    { labelKey: 'nav.services', path: '/services', icon: 'services', enabled: true },
    { labelKey: 'nav.myRequests', path: '/service-requests/my', icon: 'requests', enabled: true },
    { labelKey: 'nav.emergencyVets', path: '/emergency-vets', icon: 'emergency', enabled: true },
    { labelKey: 'nav.aiAssistant', path: '/ai', icon: 'ai', enabled: true },
    { labelKey: 'Feedback', path: '/feedback', icon: 'requests', enabled: true }
  ];

  private readonly providerNavItems: NavItem[] = [
    { labelKey: 'nav.dashboard', path: '/dashboard', icon: 'dashboard', enabled: true },
    { labelKey: 'nav.providerProfile', path: '/provider/profile', icon: 'providers', enabled: true },
    { labelKey: 'Documents & trust', path: '/provider/documents', icon: 'requests', enabled: true },
    { labelKey: 'nav.providerServices', path: '/provider/services', icon: 'services', enabled: true },
    { labelKey: 'nav.serviceAreas', path: '/provider/service-areas', icon: 'emergency', enabled: true },
    { labelKey: 'nav.incomingRequests', path: '/provider/requests', icon: 'requests', enabled: true },
    { labelKey: 'nav.aiAssistant', path: '/ai', icon: 'ai', enabled: true },
    { labelKey: 'Feedback', path: '/feedback', icon: 'requests', enabled: true }
  ];

  private readonly adminNavItems: NavItem[] = [
    { labelKey: 'nav.dashboard', path: '/dashboard', icon: 'dashboard', enabled: true },
    { labelKey: 'Admin users', path: '/admin/users', icon: 'providers', enabled: true },
    { labelKey: 'Provider verification', path: '/admin/provider-verification', icon: 'providers', enabled: true },
    { labelKey: 'Marketplace operations', path: '/admin/operations', icon: 'requests', enabled: true },
    { labelKey: 'Admin pets', path: '/admin/pets', icon: 'pets', enabled: true },
    { labelKey: 'Pet taxonomy', path: '/admin/taxonomy', icon: 'services', enabled: true },
    { labelKey: 'Geography', path: '/admin/geography', icon: 'emergency', enabled: true },
    { labelKey: 'Service catalog', path: '/admin/service-catalog', icon: 'services', enabled: true },
    { labelKey: 'nav.reminderTemplates', path: '/admin/reminder-templates', icon: 'reminders', enabled: true },
    { labelKey: 'nav.expenseCategories', path: '/admin/expense-categories', icon: 'expenses', enabled: true }
  ];

  readonly languageOptions = SUPPORTED_LANGUAGES;
  readonly currentUser: AuthUser | null = this.authService.getCurrentUser();

  constructor(
    private readonly authService: AuthService,
    readonly i18nService: I18nService,
    private readonly preferencesService: UserPreferencesService
  ) {}

  ngOnInit(): void {
    this.preferencesService.load(true).subscribe();
  }

  get displayName(): string {
    return this.currentUser?.name || 'PetLife User';
  }

  get displayRole(): string {
    return this.currentUser?.role || 'Customer';
  }

  get navItems(): NavItem[] {
    if (this.isAdmin) return this.adminNavItems;
    return this.isProvider ? this.providerNavItems : this.customerNavItems;
  }

  get isProvider(): boolean {
    return (this.currentUser?.role || '').toLowerCase().includes('provider');
  }

  get isAdmin(): boolean {
    return (this.currentUser?.role || '').toLowerCase() === 'admin';
  }

  get hubTitleKey(): string {
    if (this.isAdmin) return 'Admin workspace';
    return this.isProvider ? 'dashboard.providerHub' : 'dashboard.customerHub';
  }

  get workspaceBadgeKey(): string {
    if (this.isAdmin) return 'Admin';
    return this.isProvider ? 'dashboard.providerWorkspace' : 'shell.workspaceBadge';
  }

  logout(): void {
    this.closeDrawer();
    this.preferencesService.resetSession();
    this.authService.logout();
  }

  changeLanguage(language: AppLanguage): void {
    this.i18nService.useLanguage(language);
  }

  toggleDrawer(): void {
    this.isDrawerOpen = !this.isDrawerOpen;
    this.syncPageScroll();
  }

  closeDrawer(): void {
    this.isDrawerOpen = false;
    this.syncPageScroll();
  }

  ngOnDestroy(): void {
    document.body.classList.remove('app-drawer-open');
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.closeDrawer();
  }

  @HostListener('window:resize')
  onResize(): void {
    if (window.innerWidth >= 1024) {
      this.closeDrawer();
    }
  }

  private syncPageScroll(): void {
    document.body.classList.toggle('app-drawer-open', this.isDrawerOpen && window.innerWidth < 1024);
  }
}
